#include <stdio.h>

const double NORMAL_THRESHOLD = 18.5;
const double OVERWEIGHT_THRESHOLD = 25;
const double OBESE_THRESHOLD = 30;

const char* bmi_description(const double bmi)
{
	if (bmi < NORMAL_THRESHOLD)
		return "Underweight";
	else if (bmi < OVERWEIGHT_THRESHOLD)
		return "Normal";
	else if (bmi < OBESE_THRESHOLD)
		return "Overweight";

	return "Obese";
}

int main(void)
{
	double weight = 0.0;
	double height = 0.0;
	double bmi = 0.0;

	printf("Please enter you weight in kg: ");
	while (scanf("%lf", &weight) <= 0)
		scanf("%*s");

	printf("Please enter you height in m: ");
	while (scanf("%lf", &height) <= 0)
		scanf("%*s");

	bmi = weight / height / height;

	printf(
		"BMI VALUES\n"
		"Underweight: less than %.1lf\n"
		"Normal: between %.1lf and %.1lf\n"
		"Overweight: between %.1lf and %.1lf\n"
		"Obese: %.1lf or greater\n"
		"---------------------------------\n"
		"Yours: %.1lf - %s\n",
		NORMAL_THRESHOLD,
		NORMAL_THRESHOLD, OVERWEIGHT_THRESHOLD-0.1,
		OVERWEIGHT_THRESHOLD, OBESE_THRESHOLD-0.1,
		OBESE_THRESHOLD,
		bmi, bmi_description(bmi));

	return 0;
}
