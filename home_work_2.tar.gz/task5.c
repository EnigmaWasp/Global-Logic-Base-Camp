#include <stdio.h>
#include <limits.h>

int main(void)
{
	size_t n = 0, i = 0;
	int smallest = INT_MAX;
	int number;

	printf("Please enter the number of integers to test: ");
	while (scanf("%zu", &n) <= 0)
		scanf("%*s");

	for (i = 0; i < n; i++) {
		printf("Please enter the number #%zu: ", i);
		while (scanf("%d", &number) <= 0)
			scanf("%*s");
		if (number < smallest)
			smallest = number;
	}

	printf("Smallest number is %d\n", smallest);

	return 0;
}
