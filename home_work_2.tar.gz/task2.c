#include <stdio.h>
#include <limits.h>

int main(void)
{
	const size_t N = 3;
	int number = 0;
	int sum = 0;
	long product = 1;
	int max = INT_MIN;
	int min = INT_MAX;
	size_t i = 0;

	for (i = 0; i < N; i++) {
		while (scanf("%d", &number) <= 0 )
			scanf("%*s");
		sum += number;
		product *= number;
		if (max < number)
			max = number;
		if (min > number)
			min = number;
	}

	printf("Sum: %d\n", sum);
	printf("Product: %ld\n", product);
	printf("Largest: %d\n", max);
	printf("Smallest: %d\n", min);

	return 0;
}
