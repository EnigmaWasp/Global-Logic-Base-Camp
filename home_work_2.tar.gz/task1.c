#include <stdio.h>

int main(void)
{
	int first, second;

	while (scanf("%d", &first) <= 0)
		scanf("%*s");
	while (scanf("%d", &second) <= 0)
		scanf("%*s");

	printf("%d is%s a multiplier of %d\n",
		first, second % first? " not" : "", second);

	return 0;
}
