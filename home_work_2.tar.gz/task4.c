#include <stdio.h>
#include <stdbool.h>

int main(void)
{
	char number[5] = { 0 };
	bool is_palindrome = false;

	printf("Please enter five digits integer: ");
	(void)scanf("%5s", number);

	is_palindrome = number[0] &&
		(number[0] == number[4]) &&
		(number[1] == number[3]);

	printf("\"%.5s\" is%s a five digits integer palindrome\n",
		number, is_palindrome? "": " not");

	return 0;
}
