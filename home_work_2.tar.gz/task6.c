#include <stdio.h>
#include <math.h>

int main(void)
{
	const double MAX_PRECISION = 1e-15;
	double e = 0.0, new_e = 0.0;
	unsigned long long fact = 1;
	size_t step = 1;

	do {
		e = new_e;
		new_e += 1.0/fact;
		fact *= step++;
	} while (fabs(new_e - e) > MAX_PRECISION);

	printf("e = %.15lf\n", e);

	return 0;
}
