#include <stdio.h>
#include <math.h>

int main(void)
{
	/* MAX_PRECISION == 1e-15 (more or less precision limit for double) is
	 * calculating for 6minutes and actual precision of the PI received is
	 * 1e-8.
	 *
	 * Improving MAX_PRECISION together with changing pi and new_pi types to
	 * long double looks less promising, than the algorithm changing.
	 *
	 * MAX_PRECISION is set to 1e-10 because of speed considerations. Actual
	 * resulting precision of a received PI is 1e-5
	 */
	const double MAX_PRECISION = 1e-10;
	double pi = 0.0, new_pi = 0.0;
	size_t step = 1;

	do {
		pi = new_pi;
		new_pi += 8.0/step/(step+2);
		step += 4;
	} while (fabs(new_pi - pi) > MAX_PRECISION);

	printf("pi = %.5lf\n", pi);

	return 0;
}
